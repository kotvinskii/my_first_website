<?php
require_once 'auth_check.php';
session_start();
require 'connect.php';
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    // Валидация
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Введите корректный Email';
    }
    if (empty($password)) {
        $errors['password'] = 'Пароль — обязательное поле';
    }

    if (empty($errors)) {
        // Ищем пользователя только по email
        $sql = "SELECT * FROM tUsers WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(['email' => $email]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        // Проверяем пользователя и хеш пароля
        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['fidUser'] ?? $user['user_id'];
            header("Location: index_register.php");
            exit;
        } else {
            // Единая ошибка для логина/пароля во избежание перебора
            $errors['auth'] = 'Неверный логин или пароль';
        }
    }
}
?>


<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Авторизация</title>
    <style>
        .error { color: red; font-size: 0.9em; margin-bottom: 10px; }
    </style>
</head>
<body>
    <h2>Вход в систему</h2>
    <!-- Вывод общей ошибки авторизации -->
    <?php if (!empty($errors['auth'])): ?>
        <p class="error"><?= htmlspecialchars($errors['auth']) ?></p>
    <?php endif; ?>

    
    <form method="POST">
        <label>Email (Логин):</label><br>
        <!-- Изменили name="username" на name="email" и сохраняем введенный текст -->
        <input type="email" name="email" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"><br>
        <?php if (!empty($errors['email'])): ?>
            <span class="error"><?= $errors['email'] ?></span><br>
        <?php endif; ?><br>
        
        <label>Пароль:</label><br>
        <input type="password" name="password" required><br>
        <?php if (!empty($errors['password'])): ?>
            <span class="error"><?= $errors['password'] ?></span><br>
        <?php endif; ?><br>
        
        <!-- Заменили ссылку <a> на настоящую кнопку отправки формы -->
        <button type="submit" class="my-button">Войти</button>
    </form>
    <br>
    <a href="validation.php">Еще нет аккаунта? Зарегистрироваться</a>
</body>
</html>

